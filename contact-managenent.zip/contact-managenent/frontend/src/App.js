import React, { useState, useEffect } from 'react';
import ContactForm from './components/ContactForm';
import ContactsTable from './components/ContactsTable';
import { fetchContacts, addContact, updateContact, deleteContact } from './services/api';


const App = () => {
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    const loadContacts = async () => {
      const data = await fetchContacts();
      setContacts(data);
    };
    loadContacts();
  }, []);

  const handleAddContact = async (contact) => {
    await addContact(contact);
    const updatedContacts = await fetchContacts();
    setContacts(updatedContacts);
  };

  const handleEditContact = async (id, updatedContact) => {
    await updateContact(id, updatedContact);
    const updatedContacts = await fetchContacts();
    setContacts(updatedContacts);
  };

  const handleDeleteContact = async (id) => {
    await deleteContact(id);
    const updatedContacts = await fetchContacts();
    setContacts(updatedContacts);
  };

  return (
    <div>
      <ContactForm onSubmit={handleAddContact} />
      <ContactsTable
        contacts={contacts}
        onEdit={handleEditContact}
        onDelete={handleDeleteContact}
      />
    </div>
  );
};

export default App;
