import axios from 'axios';

const fetchContacts = async () => {
  try {
    const response = await axios.get('http://localhost:5000/contacts');
    return response.data;
  } catch (error) {
    console.error('Error fetching contacts:', error.message);
    return [];
  }
};

const addContact = async (contact) => {
  try {
    await axios.post('http://localhost:5000/contacts', contact);
  } catch (error) {
    console.error('Error adding contact:', error.message);
  }
};

const updateContact = async (_id, updatedContact) => {
  try {
    await axios.put(`http://localhost:5000/contacts/${_id}`, updatedContact);
  } catch (error) {
    console.error('Error updating contact:', error.message);
  }
};

const deleteContact = async (_id) => {
  try {
    const confirmDelete = window.confirm('Are you sure you want to delete this contact?');
    if (confirmDelete) {
      const response = await axios.delete(`http://localhost:5000/contacts/${_id}`);
      if (response.status === 200) {
        console.log('Contact deleted successfully');
      }
    }
  } catch (error) {
    if (error.response && error.response.status === 404) {
      console.error('Error: Contact not found (404)');
    } else {
      console.error('Error deleting contact:', error.message);
    }
  }
};

export { fetchContacts, addContact, updateContact, deleteContact };
