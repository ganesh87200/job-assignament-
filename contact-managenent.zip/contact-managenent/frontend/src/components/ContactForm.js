import React, { useState } from 'react';
import { TextField, Button, Box } from '@mui/material';

function ContactForm({ onSubmit }) {
  const [contact, setContact] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    jobTitle: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setContact({ ...contact, [name]: value });
  };

  const handleSubmit = () => {
    if (
      contact.firstName &&
      contact.lastName &&
      contact.email &&
      contact.phone &&
      contact.company &&
      contact.jobTitle
    ) {
      onSubmit(contact);
      setContact({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        company: '',
        jobTitle: '',
      });
    } else {
      alert('Please fill out all fields.');
    }
  };

  return (
    <Box sx={{ maxWidth: '400px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {Object.keys(contact).map((field) => (
        <TextField
          key={field}
          label={field.replace(/([A-Z])/g, ' $1')}
          name={field}
          value={contact[field]}
          onChange={handleChange}
          variant="outlined"
          fullWidth
        />
      ))}
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Add Contact
      </Button>
    </Box>
  );
}

export default ContactForm;
